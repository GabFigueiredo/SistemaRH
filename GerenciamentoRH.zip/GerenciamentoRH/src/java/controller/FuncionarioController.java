package controller;

import dao.FuncionarioDAO;
import jakarta.servlet.RequestDispatcher;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Funcionario;

@WebServlet(name = "FuncionarioController", urlPatterns = {"/FuncionarioController"})
public class FuncionarioController extends HttpServlet {
    
    private FuncionarioDAO funcionarioDAO;

    @Override
    public void init() throws ServletException {
        funcionarioDAO = new FuncionarioDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");

        if (action == null) {
            action = "listar";
        }

        switch (action) {
            case "novo" -> mostrarFormularioCadastro(request, response);
            case "editar" -> {
                try {
                    mostrarFormularioEdicao(request, response);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(FuncionarioController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            case "excluir" -> {
                try {
                    deletarFuncionario(request, response);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(FuncionarioController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            case "detalhes" -> {
                int id = Integer.parseInt(request.getParameter("id"));
                Funcionario funcionario = null;
                try {
                    funcionario = funcionarioDAO.buscarFuncionario(id);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(FuncionarioController.class.getName()).log(Level.SEVERE, null, ex);
                }
                request.setAttribute("funcionario", funcionario);
                request.getRequestDispatcher("/pages/detalhesFuncionario.jsp").forward(request, response);
            }
            
            case "SUCESSO_EXCLUSAO" -> {
                request.getRequestDispatcher("/pages/sucessoExclusao.jsp")
                        .forward(request, response);
            }
            
            case "SUCESSO_ALTERACAO" -> {
                request.getRequestDispatcher("/pages/sucessoAlteracao.jsp")
                        .forward(request, response);
            }
            
            case "SUCESSO_CRIACAO" -> {
                request.getRequestDispatcher("/pages/sucessoCriacao.jsp")
                        .forward(request, response);
            }
            
            case "CPF_EXISTENTE" -> {
                request.getRequestDispatcher("/pages/cpfExistente.jsp")
                        .forward(request, response);
            }
            default -> {
                try {
                    listarFuncionarios(request, response);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(FuncionarioController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");

        if (action == null) {
            action = "";
        }

        switch (action) {
            case "inserir" -> {
                try {
                    inserirFuncionario(request, response);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(FuncionarioController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            case "atualizar" -> {
                try {
                    atualizarFuncionario(request, response);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(FuncionarioController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

            default -> response.sendRedirect("funcionario?action=listar");
        }
    }
    

    // 🔸 Listar funcionários
    private void listarFuncionarios(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException {
        List<Funcionario> lista = funcionarioDAO.listarFuncionarios();
        request.setAttribute("listaFuncionarios", lista);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/listarFuncionarios.jsp");
        dispatcher.forward(request, response);
    }

    // 🔸 Mostrar formulário de cadastro
    private void mostrarFormularioCadastro(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/formFuncionario.jsp");
        dispatcher.forward(request, response);
    }

    // 🔸 Mostrar formulário de edição
    private void mostrarFormularioEdicao(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException {
        int id = Integer.parseInt(request.getParameter("id"));
        Funcionario funcionario = funcionarioDAO.buscarFuncionario(id);
        request.setAttribute("funcionario", funcionario);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/formFuncionario.jsp");
        dispatcher.forward(request, response);
    }

    // 🔸 Inserir funcionário
    private void inserirFuncionario(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ClassNotFoundException {
        
        Funcionario funcionario = construirFuncionarioDoRequest(request);
        
        if (!cpfExiste(funcionario.getCpf())) {
                funcionarioDAO.criarFuncionario(funcionario);
                response.sendRedirect("FuncionarioController?action=SUCESSO_CRIACAO");
        } else {
            response.sendRedirect("FuncionarioController?action=CPF_EXISTENTE");
        }
        
    }

    // 🔸 Atualizar funcionário
    private void atualizarFuncionario(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ClassNotFoundException {

        int id = Integer.parseInt(request.getParameter("id"));
        Funcionario funcionario = construirFuncionarioDoRequest(request);
        funcionario.setId(id);
        
        if (!cpfExiste(funcionario.getCpf())) {
            funcionarioDAO.atualizarFuncionario(id, funcionario);
            response.sendRedirect("FuncionarioController?action=SUCESSO_ALTERACAO");
        } else {
            response.sendRedirect("FuncionarioController?action=CPF_EXISTENTE");
        }
    }

    // 🔸 Deletar funcionário
    private void deletarFuncionario(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ClassNotFoundException {
        int id = Integer.parseInt(request.getParameter("id"));
        funcionarioDAO.deletarFuncionario(id);
        response.sendRedirect("FuncionarioController?action=SUCESSO_EXCLUSAO");
    }

    // 🔧 Método auxiliar para construir um funcionário com base no formulário
    private Funcionario construirFuncionarioDoRequest(HttpServletRequest request) {
        String nome = request.getParameter("nome");
        String cpf = request.getParameter("cpf");
        String cargo = request.getParameter("cargo");
        String departamento = request.getParameter("departamento");
        double salario = Double.parseDouble(request.getParameter("salario"));
        String email = request.getParameter("email");
        String telefone = request.getParameter("telefone");
        String dataAdmissao = request.getParameter("dataAdmissao");
        boolean ativo = request.getParameter("ativo") != null;

        return new Funcionario(1, nome, cpf, cargo, departamento, salario, email, telefone, dataAdmissao, ativo);
    }
    
    private boolean cpfExiste(String cpf) throws ClassNotFoundException {
        return funcionarioDAO.cpfExiste(cpf);
    }

    /**
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet FuncionarioController</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet FuncionarioController at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }


    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
