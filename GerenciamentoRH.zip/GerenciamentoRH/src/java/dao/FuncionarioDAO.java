package dao;

import database.ConectaBanco;
import model.Funcionario;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FuncionarioDAO {

    public List<Funcionario> listarFuncionarios() throws ClassNotFoundException {
        List<Funcionario> funcionarios = new ArrayList<>();
        String sql = "SELECT * FROM funcionarios";

        try (Connection conexao = ConectaBanco.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Funcionario f = new Funcionario(
                        rs.getInt("id"),
                        rs.getString("nome"),
                        rs.getString("cpf"),
                        rs.getString("cargo"),
                        rs.getString("departamento"),
                        rs.getDouble("salario"),
                        rs.getString("email"),
                        rs.getString("telefone"),
                        rs.getString("data_admissao"),
                        rs.getBoolean("ativo")
                );
                funcionarios.add(f);
            }

        } catch (SQLException e) {
            System.out.println("Erro ao listar funcionários: " + e.getMessage());
        }

        return funcionarios;
    }

    public void criarFuncionario(Funcionario f) throws ClassNotFoundException {
        String sql = "INSERT INTO funcionarios (nome, cpf, cargo, departamento, salario, email, telefone, data_admissao, ativo) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conexao = ConectaBanco.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setString(1, f.getNome());
            stmt.setString(2, f.getCpf());
            stmt.setString(3, f.getCargo());
            stmt.setString(4, f.getDepartamento());
            stmt.setDouble(5, f.getSalario());
            stmt.setString(6, f.getEmail());
            stmt.setString(7, f.getTelefone());
            stmt.setString(8, f.getDataAdmissao());
            stmt.setBoolean(9, f.isAtivo());

            stmt.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Erro ao criar funcionário: " + e.getMessage());
        }
    }

    public Funcionario buscarFuncionario(int id) throws ClassNotFoundException {
        String sql = "SELECT * FROM funcionarios WHERE id = ?";
        Funcionario f = null;

        try (Connection conexao = ConectaBanco.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                f = new Funcionario(
                        rs.getInt("id"),
                        rs.getString("nome"),
                        rs.getString("cpf"),
                        rs.getString("cargo"),
                        rs.getString("departamento"),
                        rs.getDouble("salario"),
                        rs.getString("email"),
                        rs.getString("telefone"),
                        rs.getString("data_admissao"),
                        rs.getBoolean("ativo")
                );
            }

        } catch (SQLException e) {
            System.out.println("Erro ao buscar funcionário: " + e.getMessage());
        }

        return f;
    }

    public void atualizarFuncionario(int id, Funcionario f) throws ClassNotFoundException {
        String sql = "UPDATE funcionarios SET nome = ?, cpf = ?, cargo = ?, departamento = ?, salario = ?, " +
                     "email = ?, telefone = ?, data_admissao = ?, ativo = ? WHERE id = ?";

        try (Connection conexao = ConectaBanco.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setString(1, f.getNome());
            stmt.setString(2, f.getCpf());
            stmt.setString(3, f.getCargo());
            stmt.setString(4, f.getDepartamento());
            stmt.setDouble(5, f.getSalario());
            stmt.setString(6, f.getEmail());
            stmt.setString(7, f.getTelefone());
            stmt.setString(8, f.getDataAdmissao());
            stmt.setBoolean(9, f.isAtivo());
            stmt.setInt(10, id);

            stmt.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Erro ao atualizar funcionário: " + e.getMessage());
        }
    }

    public void deletarFuncionario(int id) throws ClassNotFoundException {
        String sql = "DELETE FROM funcionarios WHERE id = ?";

        try (Connection conexao = ConectaBanco.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setInt(1, id);
            stmt.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Erro ao deletar funcionário: " + e.getMessage());
        }
    }

    public boolean cpfExiste(String cpf) throws ClassNotFoundException {
        String sql = "SELECT COUNT(*) FROM funcionarios WHERE cpf = ?";
        boolean existe = false;

        try (Connection conexao = ConectaBanco.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setString(1, cpf);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                existe = rs.getInt(1) > 0;
            }

        } catch (SQLException e) {
            System.out.println("Erro ao verificar CPF: " + e.getMessage());
        }

        return existe;
    }

    
    public boolean validarDadosFuncionario(Funcionario f) {
        return f.getNome() != null && !f.getNome().isEmpty()
                && f.getCpf() != null && !f.getCpf().isEmpty()
                && f.getCargo() != null && !f.getCargo().isEmpty()
                && f.getDepartamento() != null && !f.getDepartamento().isEmpty()
                && f.getEmail() != null && !f.getEmail().isEmpty()
                && f.getTelefone() != null && !f.getTelefone().isEmpty()
                && f.getDataAdmissao() != null && !f.getDataAdmissao().isEmpty();
    }
}
